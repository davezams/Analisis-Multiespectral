def funcion (req, nombre):
	print("¡Hola,", nombre, "!")